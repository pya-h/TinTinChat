# TinTinChat — Session Bootstrap Context

Last updated: 2026-03-11
Repository: `pya-h/TinTinChat`
Branch: `dev` (default: `master`)

## 1) Current State (Distilled)

TinTinChat is in **post-Phase J.2 stabilization**.
Core direct/group chat, encryption flows, stickers, PWA baseline, group seen/unread refinements, block user, and automated test coverage are implemented and stable.

### Phase snapshot
- Completed: A, B, C, D, E, E.1, E.2, F, F.5, F.6, G, H, I, J
- Completed: J.2 (group seen/unread refinements)

Primary source-of-truth task list: `docs/TASKS.md`.

## 2) What This Session Changed

### Security/auth hardening
- Logout is now **POST + CSRF protected** (state-changing GET logout removed).
- Login failure redirect path handling was normalized to the route-safe helper.

Files:
- `dashboard.php`
- `api/auth/logout.php`
- `api/auth/login.php`

### Frontend cleanup + UX polish
- Removed production debug logging in message refresh path.
- Removed unused jQuery runtime dependency and deleted `assets/js/ext/jquery-3.6.1.min.js`.
- Removed dead/duplicated UI-enhancement logic:
  - no-op typing timeout,
  - duplicate ripple keyframe injection,
  - pull-to-refresh now calls an actual refresh helper.
- Improved motion/accessibility behavior:
  - explicit reduced-motion fallbacks for high-motion UI zones,
  - improved composer disabled-state visual consistency,
  - tightened chat-composer button layering/contrast consistency.

Files (main):
- `assets/js/chat.js`
- `assets/js/ui-enhancements.js`
- `assets/css/dashboard.css`
- `assets/css/style.css`
- `dashboard.php`

### J.2 group seen/unread + mobile drawer UX
- Added smartphone pull-down chat-list drawer behavior for hidden mobile chat list (toggle + pull gesture + backdrop close).
- Implemented group first-viewer seen semantics:
  - first non-sender member that views marks message as seen (`group_seen_at`, `group_seen_by_user_id`).
- Implemented per-user group unread counters in chat/group fetch APIs via read pointer tracking.
- Added read-pointer persistence table for group membership (`group_member_reads`).

Files:
- `dashboard.php`
- `assets/css/dashboard.css`
- `assets/js/chat.js`
- `includes/group_helpers.php`
- `api/messages/fetch.php`
- `api/messages/fetch_recent.php`
- `api/chats/fetch.php`
- `api/groups/fetch.php`
- `migrations/17_add_group_seen_unread_support.sql`
- `migrations/XX_schema.final.sql`

### Backend cleanup + low-risk optimization
- Removed unreferenced helpers after workspace usage scan:
  - `includes/auth.php`: removed `getUserByUsername`, `createUser`
  - `includes/session.php`: removed `sanitizeString`
- Hot path query micro-optimizations:
  - message fetch user lookup now uses `LIMIT 1`
  - message count retrieval uses `fetchColumn()`

Files:
- `api/messages/fetch.php`
- `api/messages/fetch_recent.php`
- `includes/auth.php`
- `includes/session.php`

### Docs synchronization
- Synced and normalized project docs to match the current architecture/flows and test status.

Files:
- `README.md`
- `docs/TASKS.md`
- `docs/SECURITY_CHECKLIST.md`
- `docs/TECHNICAL_DESIGN.md`
- `CONTEXT.md`

## 3) Architecture Reality (Now)

- Backend: PHP + PDO + MySQL
- Frontend: server-rendered pages + vanilla JS/CSS
- Routing: organized API domains only (`api/auth|chats|groups|keys|messages|system|typing|users`)
- Crypto model:
  - direct text: RSA-OAEP flow
  - group text: shared key flow
  - media/file: encrypted envelope model
- Runtime model: polling-based updates for chat/messages/typing/seen

## 4) Verification Status

- Full automated suite passes: `bash tests/run_all_tests.sh`
- Re-run multiple times after each major change batch this session.
- No API contract changes introduced by cleanup/optimization pass.

## 5) Known Active Priorities (Next Session)

1. Continue defense-in-depth and regression checks while post-J.2 changes are implemented.
2. Track PWA rollout observations and adjust cache/version policies as needed.
3. Consider optional realtime refinement for group-seen tick updates.

## 6) Guardrails for Next Session

- Preserve organized endpoint structure (no legacy flat `api/*.php` wrappers).
- Keep auth/mutating guard order consistent (`method -> auth -> csrf -> validate -> logic -> response`).
- Keep docs synced whenever behavior/contracts change:
  - `README.md`
  - `docs/TASKS.md`
  - `docs/API_CONTRACT.md`
  - `docs/TECHNICAL_DESIGN.md`
  - `CONTEXT.md`

## 7) Fast Bootstrap Checklist

- Read in order:
  1. `CONTEXT.md`
  2. `docs/TASKS.md`
  3. `docs/TECHNICAL_DESIGN.md`
  4. `docs/API_CONTRACT.md`
- Validate baseline locally:
  - `bash tests/run_all_tests.sh`
- Start from post-J.2 polish/optimization items unless priorities changed.
