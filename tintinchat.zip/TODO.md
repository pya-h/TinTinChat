## Priorities
<ul>
    <li><b>[IMP]</b> Enhance Security</li>
    <li><del><b>[ADD]</b> Play Sound on New Messages</del></li>
    <li><del><b>[ADD]</b> File Upload Feature</del></li> 
    <li><b>[REFACTOR]</b> Create a APIService class in js</li> 
    <li><b>[ADD]</b> Implement Chat Model & Table</li>
</ul>

## Less Priors
<ul>
    <li><del><b>[IMP]</b> Make Delivery Report system More Interactive: No Reload Required to See Ticks</del></li>
    <li><b>[ADD]</b> Music & Video Upload Too (Separate message types for Music & Video messages) </li> 
    <li><b>[ADD]</b> Show Message Menu by Long Click</li>
    <li><b>[ADD]</b> Use delete_message endpoint</li>
    <li><b>[IMP]</b> Add $_SERVER['REQUEST_METHOD'] check on all endpoints</li> 

</ul>